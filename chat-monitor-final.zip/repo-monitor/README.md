# 💬 Chat Monitor — Google Chat

Monitor de mensagens do Google Chat em tempo real. Todas as mensagens enviadas nos espaços configurados aparecem instantaneamente no dashboard web.

## Funcionalidades

- Feed de mensagens em tempo real (atualiza a cada 10s)
- Sidebar com espaços detectados automaticamente
- Filtro por espaço, busca por nome, e-mail ou conteúdo
- Destaque visual para mensagens novas
- Exportação CSV
- Dashboard React + Tailwind hospedado no Netlify

**Stack:** Python 3.11 · Google Cloud Functions · Firestore · React + Tailwind · Netlify

---

## 🚀 Deploy

### 1. Criar projeto e ativar APIs
```bash
gcloud projects create meu-chat-monitor
gcloud config set project meu-chat-monitor

gcloud services enable \
  cloudfunctions.googleapis.com \
  chat.googleapis.com \
  firestore.googleapis.com

gcloud firestore databases create --region=southamerica-east1
```

### 2. Deploy da Cloud Function
```bash
cd src

gcloud functions deploy monitor_chat \
  --gen2 --runtime=python311 \
  --region=southamerica-east1 \
  --entry-point=monitor_chat \
  --trigger-http --allow-unauthenticated \
  --memory=256Mi --timeout=30s
```
Anote a URL gerada.

### 3. Dashboard no Netlify
1. Edite `dashboard/_redirects` substituindo `SEU-PROJETO` pela URL real da Cloud Function
2. Acesse [app.netlify.com](https://app.netlify.com) → Add new site → Deploy manually
3. Arraste a pasta `dashboard/`
4. Acesse a URL gerada e cole a URL da Cloud Function no campo de configuração

### 4. Registrar o app no Google Chat
1. `console.cloud.google.com` → Google Chat API → Configuração
2. Nome: **Monitor de Chat** · URL do app: URL da Cloud Function
3. Ative: **Receber mensagens em espaços** · Visibilidade: seu domínio
4. Adicione o app nos espaços que deseja monitorar

---

## 🗂 Estrutura

```
├── src/
│   ├── main.py      # Webhook + API de mensagens
│   └── banco.py     # Firestore
├── dashboard/
│   ├── index.html   # Dashboard React + Tailwind
│   ├── _redirects   # Proxy Netlify → Cloud Function
│   └── netlify.toml
└── requirements.txt
```

## ⚙️ Variáveis de ambiente

| Variável | Descrição |
|---|---|
| `DASHBOARD_ORIGIN` | Origem CORS permitida (padrão: `*`) |

## 📄 Licença
MIT
